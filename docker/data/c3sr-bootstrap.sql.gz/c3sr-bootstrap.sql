--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1 (Debian 14.1-1.pgdg110+1)
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: architectures; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.architectures (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    name text,
    framework_id bigint
);


ALTER TABLE public.architectures OWNER TO c3sr;

--
-- Name: architectures_id_seq; Type: SEQUENCE; Schema: public; Owner: c3sr
--

CREATE SEQUENCE public.architectures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.architectures_id_seq OWNER TO c3sr;

--
-- Name: architectures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: c3sr
--

ALTER SEQUENCE public.architectures_id_seq OWNED BY public.architectures.id;


--
-- Name: experiments; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.experiments (
    id text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    user_id text
);


ALTER TABLE public.experiments OWNER TO c3sr;

--
-- Name: frameworks; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.frameworks (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    name text,
    version text
);


ALTER TABLE public.frameworks OWNER TO c3sr;

--
-- Name: frameworks_id_seq; Type: SEQUENCE; Schema: public; Owner: c3sr
--

CREATE SEQUENCE public.frameworks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.frameworks_id_seq OWNER TO c3sr;

--
-- Name: frameworks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: c3sr
--

ALTER SEQUENCE public.frameworks_id_seq OWNED BY public.frameworks.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.migrations (
    migration bigint,
    migrated_at timestamp with time zone
);


ALTER TABLE public.migrations OWNER TO c3sr;

--
-- Name: models; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.models (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    attribute_top1 text,
    attribute_top5 text,
    attribute_kind text,
    attribute_manifest_author text,
    attribute_training_dataset text,
    description text,
    detail_graph_checksum text,
    detail_graph_path text,
    detail_weights_checksum text,
    detail_weights_path text,
    framework_id bigint,
    input_description text,
    input_type text,
    license text,
    name text,
    output_description text,
    output_type text,
    version text
);


ALTER TABLE public.models OWNER TO c3sr;

--
-- Name: models_id_seq; Type: SEQUENCE; Schema: public; Owner: c3sr
--

CREATE SEQUENCE public.models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.models_id_seq OWNER TO c3sr;

--
-- Name: models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: c3sr
--

ALTER SEQUENCE public.models_id_seq OWNED BY public.models.id;


--
-- Name: trial_inputs; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.trial_inputs (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    trial_id text,
    url text,
    user_id text
);


ALTER TABLE public.trial_inputs OWNER TO c3sr;

--
-- Name: trial_inputs_id_seq; Type: SEQUENCE; Schema: public; Owner: c3sr
--

CREATE SEQUENCE public.trial_inputs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trial_inputs_id_seq OWNER TO c3sr;

--
-- Name: trial_inputs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: c3sr
--

ALTER SEQUENCE public.trial_inputs_id_seq OWNED BY public.trial_inputs.id;


--
-- Name: trials; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.trials (
    id text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    model_id bigint,
    completed_at timestamp with time zone,
    result text,
    experiment_id text
);


ALTER TABLE public.trials OWNER TO c3sr;

--
-- Name: users; Type: TABLE; Schema: public; Owner: c3sr
--

CREATE TABLE public.users (
    id text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO c3sr;

--
-- Name: architectures id; Type: DEFAULT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.architectures ALTER COLUMN id SET DEFAULT nextval('public.architectures_id_seq'::regclass);


--
-- Name: frameworks id; Type: DEFAULT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.frameworks ALTER COLUMN id SET DEFAULT nextval('public.frameworks_id_seq'::regclass);


--
-- Name: models id; Type: DEFAULT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.models ALTER COLUMN id SET DEFAULT nextval('public.models_id_seq'::regclass);


--
-- Name: trial_inputs id; Type: DEFAULT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.trial_inputs ALTER COLUMN id SET DEFAULT nextval('public.trial_inputs_id_seq'::regclass);


--
-- Data for Name: architectures; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.architectures (id, created_at, updated_at, deleted_at, name, framework_id) FROM stdin;
1	2022-02-03 17:48:14.327562+00	2022-02-03 17:48:14.327562+00	\N	amd64	1
2	2022-02-03 17:48:14.679924+00	2022-02-03 17:48:14.679924+00	\N	amd64	2
3	2022-02-03 17:48:14.926679+00	2022-02-03 17:48:14.926679+00	\N	amd64	3
4	2022-02-03 17:48:15.167363+00	2022-02-03 17:48:15.167363+00	\N	amd64	4
5	2022-02-03 17:48:15.167363+00	2022-02-03 17:48:15.167363+00	\N	amd64	5
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.experiments (id, created_at, updated_at, deleted_at, user_id) FROM stdin;
\.


--
-- Data for Name: frameworks; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.frameworks (id, created_at, updated_at, deleted_at, name, version) FROM stdin;
1	2022-02-03 17:48:14.324591+00	2022-02-03 17:48:14.324591+00	\N	MXNet	1.7.0
2	2022-02-03 17:48:14.67896+00	2022-02-03 17:48:14.67896+00	\N	Onnxruntime	1.6.0
3	2022-02-03 17:48:14.925599+00	2022-02-03 17:48:14.925599+00	\N	PyTorch	1.5.0
4	2022-02-03 17:48:15.166418+00	2022-02-03 17:48:15.166418+00	\N	TensorFlow	1.14.0
5	2022-02-03 17:48:15.166418+00	2022-02-03 17:48:15.166418+00	\N	Mock	1.0.0
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.migrations (migration, migrated_at) FROM stdin;
1	2022-02-03 17:22:40.599244+00
2	2022-02-03 17:22:40.625529+00
3	2022-02-03 17:22:40.680557+00
4	2022-02-03 17:22:40.715058+00
5	2022-02-03 17:22:40.731217+00
6	2022-02-03 17:22:40.745662+00
7	2022-02-03 17:22:40.760143+00
8	2022-02-03 17:22:40.772138+00
9	2022-02-03 17:22:40.779053+00
10	2022-02-03 17:22:40.784898+00
11	2022-02-03 17:22:40.791744+00
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.models (id, created_at, updated_at, deleted_at, attribute_top1, attribute_top5, attribute_kind, attribute_manifest_author, attribute_training_dataset, description, detail_graph_checksum, detail_graph_path, detail_weights_checksum, detail_weights_path, framework_id, input_description, input_type, license, name, output_description, output_type, version) FROM stdin;
1	2022-02-03 17:48:14.331709+00	2022-02-03 17:48:14.331709+00	\N	54.92	78.03	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use AlexNet from GluonCV model zoo.\n	4abd57ec8863ff3e3e29ecd4ead43d1f	model-symbol.json	906234b2a6b14bedac2dcccba8178529	model-0000.params	1			unrestricted	AlexNet	the output label	classification	1.0
2	2022-02-03 17:48:14.340212+00	2022-02-03 17:48:14.340212+00	\N	93.0		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNet110_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNet110_v1	the output label	classification	1.0
3	2022-02-03 17:48:14.346396+00	2022-02-03 17:48:14.346396+00	\N	94.3		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNet110_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNet110_v2	the output label	classification	1.0
4	2022-02-03 17:48:14.352117+00	2022-02-03 17:48:14.352117+00	\N	92.1		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNet20_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNet20_v1	the output label	classification	1.0
5	2022-02-03 17:48:14.357652+00	2022-02-03 17:48:14.357652+00	\N	92.1		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNet20_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNet20_v2	the output label	classification	1.0
6	2022-02-03 17:48:14.363351+00	2022-02-03 17:48:14.363351+00	\N	93.6		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNet56_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNet56_v1	the output label	classification	1.0
7	2022-02-03 17:48:14.369381+00	2022-02-03 17:48:14.369381+00	\N	93.7		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNet56_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNet56_v2	the output label	classification	1.0
8	2022-02-03 17:48:14.374483+00	2022-02-03 17:48:14.374483+00	\N	96.3		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNext29_16x64d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNext29_16x64d	the output label	classification	1.0
9	2022-02-03 17:48:14.379546+00	2022-02-03 17:48:14.379546+00	\N			CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_ResNext29_32x4d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_ResNext29_32x4d	the output label	classification	1.0
10	2022-02-03 17:48:14.384531+00	2022-02-03 17:48:14.384531+00	\N	95.1		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_WideResNet16_10 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_WideResNet16_10	the output label	classification	1.0
11	2022-02-03 17:48:14.389115+00	2022-02-03 17:48:14.389115+00	\N	95.6		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_WideResNet28_10 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_WideResNet28_10	the output label	classification	1.0
12	2022-02-03 17:48:14.394007+00	2022-02-03 17:48:14.394007+00	\N	95.9		CNN	Cheng Li	CIFAR10	MXNet Image Classification model, which is trained on the ImageNet dataset. Use CIFAR_WideResNet40_8 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	CIFAR_WideResNet40_8	the output label	classification	1.0
13	2022-02-03 17:48:14.399151+00	2022-02-03 17:48:14.399151+00	\N	78.56	94.43	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use Darknet53 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	Darknet53	the output label	classification	1.0
14	2022-02-03 17:48:14.403426+00	2022-02-03 17:48:14.403426+00	\N	74.97	92.25	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use DenseNet121 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	DenseNet121	the output label	classification	1.0
15	2022-02-03 17:48:14.407984+00	2022-02-03 17:48:14.407984+00	\N	77.70	93.80	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use DenseNet161 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	DenseNet161	the output label	classification	1.0
16	2022-02-03 17:48:14.412221+00	2022-02-03 17:48:14.412221+00	\N	76.17	93.17	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use DenseNet169 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	DenseNet169	the output label	classification	1.0
17	2022-02-03 17:48:14.416751+00	2022-02-03 17:48:14.416751+00	\N	77.32	93.62	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use DenseNet201 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	DenseNet201	the output label	classification	1.0
18	2022-02-03 17:48:14.42111+00	2022-02-03 17:48:14.42111+00	\N			CNN	Cheng Li	Pascal VOC	MXNet Object Detection model, which is trained on the Pascal VOC dataset. Use faster_rcnn_resnet50_v1b_voc from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	Faster_RCNN_ResNet50_v1b_VOC	the output bounding box	boundingbox	1.0
19	2022-02-03 17:48:14.425681+00	2022-02-03 17:48:14.425681+00	\N	78.77	94.39	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use Inception_v3 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	Inception_v3	the output label	classification	1.0
20	2022-02-03 17:48:14.430184+00	2022-02-03 17:48:14.430184+00	\N	52.91	76.94	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNet0.25 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_0.25	the output label	classification	1.0
21	2022-02-03 17:48:14.435028+00	2022-02-03 17:48:14.435028+00	\N	65.20	86.34	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNet0.5 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_0.5	the output label	classification	1.0
22	2022-02-03 17:48:14.439752+00	2022-02-03 17:48:14.439752+00	\N	70.25	89.49	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNet0.75 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_0.75	the output label	classification	1.0
23	2022-02-03 17:48:14.44413+00	2022-02-03 17:48:14.44413+00	\N	73.28	91.30	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNet1.0 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_1.0	the output label	classification	1.0
24	2022-02-03 17:48:14.449173+00	2022-02-03 17:48:14.449173+00	\N	72.85	90.99	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNet1.0_int8 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_1.0_int8	the output label	classification	1.0
25	2022-02-03 17:48:14.453873+00	2022-02-03 17:48:14.453873+00	\N	51.76	74.89	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNetv2_0.25 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_v2_0.25	the output label	classification	1.0
26	2022-02-03 17:48:14.45773+00	2022-02-03 17:48:14.45773+00	\N	64.43	85.31	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNetv2_0.5 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_v2_0.5	the output label	classification	1.0
27	2022-02-03 17:48:14.461449+00	2022-02-03 17:48:14.461449+00	\N	69.36	88.50	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNetv2_0.75 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_v2_0.75	the output label	classification	1.0
28	2022-02-03 17:48:14.465477+00	2022-02-03 17:48:14.465477+00	\N	72.04	90.57	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use MobileNetv2_1.0 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	MobileNet_v2_1.0	the output label	classification	1.0
29	2022-02-03 17:48:14.46971+00	2022-02-03 17:48:14.46971+00	\N	78.34	94.01	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet101_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet101_v1	the output label	classification	1.0
30	2022-02-03 17:48:14.473731+00	2022-02-03 17:48:14.473731+00	\N	79.20	94.61	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet101_v1b from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet101_v1b	the output label	classification	1.0
31	2022-02-03 17:48:14.478021+00	2022-02-03 17:48:14.478021+00	\N	79.60	94.75	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet101_v1c from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet101_v1c	the output label	classification	1.0
32	2022-02-03 17:48:14.481855+00	2022-02-03 17:48:14.481855+00	\N	80.51	95.12	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet101_v1d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet101_v1d	the output label	classification	1.0
33	2022-02-03 17:48:14.485619+00	2022-02-03 17:48:14.485619+00	\N	78.53	94.17	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet101_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet101_v2	the output label	classification	1.0
34	2022-02-03 17:48:14.489472+00	2022-02-03 17:48:14.489472+00	\N	79.22	94.64	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet152_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet152_v1	the output label	classification	1.0
35	2022-02-03 17:48:14.49344+00	2022-02-03 17:48:14.49344+00	\N	79.69	94.74	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet152_v1b from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet152_v1b	the output label	classification	1.0
36	2022-02-03 17:48:14.497402+00	2022-02-03 17:48:14.497402+00	\N	80.01	94.96	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet152_v1c from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet152_v1c	the output label	classification	1.0
37	2022-02-03 17:48:14.501591+00	2022-02-03 17:48:14.501591+00	\N	80.61	95.34	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet152_v1d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet152_v1d	the output label	classification	1.0
38	2022-02-03 17:48:14.50514+00	2022-02-03 17:48:14.50514+00	\N	79.21	94.31	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet152_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet152_v2	the output label	classification	1.0
39	2022-02-03 17:48:14.508827+00	2022-02-03 17:48:14.508827+00	\N	70.93	89.92	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet18_v1 from GluonCV model zoo.\n	b10b9148d06b184a8ca4af3b06fe403e	model-symbol.json	fa9e658e88d4259b307a50b36a080bdc	model-0000.params	1			unrestricted	ResNet18_v1	the output label	classification	1.0
40	2022-02-03 17:48:14.513062+00	2022-02-03 17:48:14.513062+00	\N	70.94	89.83	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet18_v1b from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet18_v1b	the output label	classification	1.0
41	2022-02-03 17:48:14.517539+00	2022-02-03 17:48:14.517539+00	\N	71.00	89.92	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet18_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet18_v2	the output label	classification	1.0
42	2022-02-03 17:48:14.521985+00	2022-02-03 17:48:14.521985+00	\N	74.37	91.87	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet34_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet34_v1	the output label	classification	1.0
43	2022-02-03 17:48:14.525982+00	2022-02-03 17:48:14.525982+00	\N	74.65	92.08	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet34_v1b from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet34_v1b	the output label	classification	1.0
44	2022-02-03 17:48:14.530326+00	2022-02-03 17:48:14.530326+00	\N	74.40	92.08	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet34_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet34_v2	the output label	classification	1.0
45	2022-02-03 17:48:14.534888+00	2022-02-03 17:48:14.534888+00	\N	77.36	93.57	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet50_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet50_v1	the output label	classification	1.0
46	2022-02-03 17:48:14.540196+00	2022-02-03 17:48:14.540196+00	\N	76.86	93.46	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet50_v1_int8 from GluonCV model zoo. ResNet50_v1_int8 is a quantized model for ResNet50_v1.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet50_v1_int8	the output label	classification	1.0
47	2022-02-03 17:48:14.544636+00	2022-02-03 17:48:14.544636+00	\N	77.67	93.82	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet50_v1b from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet50_v1b	the output label	classification	1.0
48	2022-02-03 17:48:14.549064+00	2022-02-03 17:48:14.549064+00	\N	77.36	93.59	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet50_v1b_gn from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet50_v1b_gn	the output label	classification	1.0
49	2022-02-03 17:48:14.553627+00	2022-02-03 17:48:14.553627+00	\N	78.03	94.09	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet50_v1c from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet50_v1c	the output label	classification	1.0
50	2022-02-03 17:48:14.558019+00	2022-02-03 17:48:14.558019+00	\N	79.15	94.58	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet50_v1d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet50_v1d	the output label	classification	1.0
51	2022-02-03 17:48:14.56278+00	2022-02-03 17:48:14.56278+00	\N	77.11	93.43	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNet50_v2 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNet50_v2	the output label	classification	1.0
52	2022-02-03 17:48:14.567236+00	2022-02-03 17:48:14.567236+00	\N	80.37	95.06	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNext101_32x4d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNext101_32x4d	the output label	classification	1.0
53	2022-02-03 17:48:14.571526+00	2022-02-03 17:48:14.571526+00	\N	80.69	95.17	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNext101_64x4d_v1 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNext101_64x4d_v1	the output label	classification	1.0
54	2022-02-03 17:48:14.575831+00	2022-02-03 17:48:14.575831+00	\N	79.32	94.53	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use ResNext50_32x4d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	ResNext50_32x4d	the output label	classification	1.0
55	2022-02-03 17:48:14.579964+00	2022-02-03 17:48:14.579964+00	\N	80.91	95.39	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use SE_ResNext101_32x4d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SE_ResNext101_32x4d	the output label	classification	1.0
56	2022-02-03 17:48:14.584406+00	2022-02-03 17:48:14.584406+00	\N	81.01	95.32	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use SE_ResNext101_64x4d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SE_ResNext101_64x4d	the output label	classification	1.0
57	2022-02-03 17:48:14.59002+00	2022-02-03 17:48:14.59002+00	\N	79.95	94.93	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use SE_ResNext50_32x4d from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SE_ResNext50_32x4d	the output label	classification	1.0
58	2022-02-03 17:48:14.594214+00	2022-02-03 17:48:14.594214+00	\N	81.26	95.51	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use SENet_154 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SENet_154	the output label	classification	1.0
59	2022-02-03 17:48:14.598641+00	2022-02-03 17:48:14.598641+00	\N	56.11	79.09	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use SqueezeNet_v1.0 from GluonCV model zoo.\n	ddf014f8b42e26d8d60f9cc5803f8cf3	model-symbol.json	8cf396e2ec24691020fae29ffc98b88a	model-0000.params	1			unrestricted	SqueezeNet_v1.0	the output label	classification	1.0
60	2022-02-03 17:48:14.602432+00	2022-02-03 17:48:14.602432+00	\N	54.96	78.17	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use SqueezeNet_v1.1 from GluonCV model zoo.\n	4540936dae06bf9304838e3df88c24e8	model-symbol.json	1351611541c24b57015aee487f4b7d70	model-0000.params	1			unrestricted	SqueezeNet_v1.1	the output label	classification	1.0
61	2022-02-03 17:48:14.606356+00	2022-02-03 17:48:14.606356+00	\N			CNN	Cheng Li	COCO	MXNet Object Detection model, which is trained on the COCO dataset. Use ssd_300_vgg16_atrous_coco from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_300_VGG16_Atrous_COCO	the output bounding box	boundingbox	1.0
62	2022-02-03 17:48:14.610695+00	2022-02-03 17:48:14.610695+00	\N			CNN	Cheng Li	Pascal VOC	MXNet Object Detection model, which is trained on the Pascal VOC dataset. Use ssd_300_vgg16_atrous_voc from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_300_VGG16_Atrous_VOC	the output bounding box	boundingbox	1.0
63	2022-02-03 17:48:14.614771+00	2022-02-03 17:48:14.614771+00	\N			CNN	Cheng Li	COCO	MXNet Object Detection model, which is trained on the Pascal VOC dataset. Use ssd_512_resnet101_v2_coco from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_512_MobileNet_1.0_COCO	the output bounding box	boundingbox	1.0
64	2022-02-03 17:48:14.618787+00	2022-02-03 17:48:14.618787+00	\N			CNN	Cheng Li	Pascal VOC	MXNet Object Detection model, which is trained on the Pascal VOC dataset. Use ssd_512_mobilenet1.0_voc from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_512_MobileNet_1.0_VOC	the output bounding box	boundingbox	1.0
65	2022-02-03 17:48:14.623136+00	2022-02-03 17:48:14.623136+00	\N			CNN	Cheng Li	Pascal VOC	MXNet Object Detection model, which is trained on the Pascal VOC dataset. Use ssd_512_resnet101_v2_voc from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_512_ResNet101_v2_VOC	the output bounding box	boundingbox	1.0
66	2022-02-03 17:48:14.62796+00	2022-02-03 17:48:14.62796+00	\N			CNN	Cheng Li	COCO	MXNet Object Detection model, which is trained on the COCO dataset. Use ssd_512_resnet50_v1_coco from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_512_ResNet50_v1_COCO	the output bounding box	boundingbox	1.0
67	2022-02-03 17:48:14.632234+00	2022-02-03 17:48:14.632234+00	\N			CNN	Cheng Li	Pascal VOC	MXNet Object Detection model, which is trained on the Pascal VOC dataset. Use ssd_512_resnet50_v1_voc from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_512_ResNet50_v1_VOC	the output bounding box	boundingbox	1.0
68	2022-02-03 17:48:14.636486+00	2022-02-03 17:48:14.636486+00	\N			CNN	Cheng Li	COCO	MXNet Object Detection model, which is trained on the COCO dataset. Use ssd_512_vgg16_atrous_coco from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_512_VGG16_Atrous_COCO	the output bounding box	boundingbox	1.0
69	2022-02-03 17:48:14.640516+00	2022-02-03 17:48:14.640516+00	\N			CNN	Cheng Li	Pascal VOC	MXNet Object Detection model, which is trained on the Pascal VOC dataset. Use ssd_512_vgg16_atrous_voc from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	SSD_512_VGG16_Atrous_VOC	the output bounding box	boundingbox	1.0
70	2022-02-03 17:48:14.644544+00	2022-02-03 17:48:14.644544+00	\N	66.62	87.34	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG11 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG11	the output label	classification	1.0
71	2022-02-03 17:48:14.649758+00	2022-02-03 17:48:14.649758+00	\N	68.59	88.72	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG11 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG11_bn	the output label	classification	1.0
177	2022-02-03 17:48:15.16813+00	2022-02-03 17:48:15.16813+00	\N	73.29	91.45	CNN	Cheng Li	ImageNet	AI Matrix Densenet121.\n	2b8c19a4dbe84afecf22559d234f48c8	Densenet121-NHWC.pb			4			unrestricted	AI_Matrix_Densenet121	the output label	classification	1.0
72	2022-02-03 17:48:14.654407+00	2022-02-03 17:48:14.654407+00	\N	67.74	88.11	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG13 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG13	the output label	classification	1.0
73	2022-02-03 17:48:14.658797+00	2022-02-03 17:48:14.658797+00	\N	68.84	88.11	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG13_bn from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG13_bn	the output label	classification	1.0
74	2022-02-03 17:48:14.663519+00	2022-02-03 17:48:14.663519+00	\N	73.23	91.31	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG16 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG16	the output label	classification	1.0
75	2022-02-03 17:48:14.667482+00	2022-02-03 17:48:14.667482+00	\N	73.10	91.76	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG16_bn from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG16_bn	the output label	classification	1.0
76	2022-02-03 17:48:14.67132+00	2022-02-03 17:48:14.67132+00	\N	74.11	91.35	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG19 from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG19	the output label	classification	1.0
77	2022-02-03 17:48:14.675066+00	2022-02-03 17:48:14.675066+00	\N	74.33	91.85	CNN	Cheng Li	ImageNet	MXNet Image Classification model, which is trained on the ImageNet dataset. Use VGG19_bn from GluonCV model zoo.\n		model-symbol.json		model-0000.params	1			unrestricted	VGG19_bn	the output label	classification	1.0
78	2022-02-03 17:48:14.680943+00	2022-02-03 17:48:14.680943+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the Resnet publication originally written in Caffe. The pre-trained model expects input in mini-batches of 3-channel BGR images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 255] and then normalized using mean = [102.9801, 115.9465, 122.7717] and std = [1, 1, 1]\n	9f029061ed3b841cb8bf35faa72ba9ef	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/cafferesnet101-imagenet.onnx			2			unrestricted	Caffe_ResNet_101	the output label	classification	1.0
79	2022-02-03 17:48:14.685614+00	2022-02-03 17:48:14.685614+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	116b2057a202acce4f154afb8f2efbb5	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/dpn107-imagenet.onnx			2			unrestricted	DPN_107	the output label	classification	1.0
80	2022-02-03 17:48:14.68968+00	2022-02-03 17:48:14.68968+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	ce7898dd8858a699e1a22cf784e9d5e2	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/dpn131-imagenet.onnx			2			unrestricted	DPN_131	the output label	classification	1.0
81	2022-02-03 17:48:14.693913+00	2022-02-03 17:48:14.693913+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	296084b9bb1c1333c92b6b4763903d3a	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/dpn68-imagenet.onnx			2			unrestricted	DPN_68_v1.0	the output label	classification	1.0
82	2022-02-03 17:48:14.69855+00	2022-02-03 17:48:14.69855+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	627f2708c3e3c87c57a37399e7c6ae0f	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/dpn68b-imagenet.onnx			2			unrestricted	DPN_68_v2.0	the output label	classification	1.0
83	2022-02-03 17:48:14.704106+00	2022-02-03 17:48:14.704106+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	8775db63e9a1562465f689521df9d072	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/dpn92-imagenet.onnx			2			unrestricted	DPN_92	the output label	classification	1.0
84	2022-02-03 17:48:14.708913+00	2022-02-03 17:48:14.708913+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	4fe9bf94ebaa91e33b3131e1ae94ceb6	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/dpn98-imagenet.onnx			2			unrestricted	DPN_98	the output label	classification	1.0
85	2022-02-03 17:48:14.713993+00	2022-02-03 17:48:14.713993+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 299. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	d312c2726d398358f73440f20eb0c87f	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/inceptionresnetv2-imagenet.onnx			2			unrestricted	Inception_ResNet_v2.0	the output label	classification	1.0
86	2022-02-03 17:48:14.718393+00	2022-02-03 17:48:14.718393+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 299. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	31709e7318796f5fc984cedd028100a4	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/inceptionv3-imagenet.onnx			2			unrestricted	Inception_v3.0	the output label	classification	1.0
87	2022-02-03 17:48:14.722722+00	2022-02-03 17:48:14.722722+00	\N				Yen-Hsiang Chang	ImageNet	MLPerf_Mobilenet_v1_1.0_224. Use mobilenet_v1_2018_08_02/mobilenet_v1_1.0_224.tgz from TensorFlow detection model zoo.\n	5173c0ccbae0d4fe2acd514e8b847f0d	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/mobilenet_v1_1.0_224.onnx			2			Apache License, Version 2.0	MLPerf_Mobilenet_v1	the output label	classification	1.0
88	2022-02-03 17:48:14.72743+00	2022-02-03 17:48:14.72743+00	\N			CNN	Yen-Hsiang Chang	ImageNet	MLPerf_ResNet50_v1.5.\n	a638cf028b5870da29e09ccc2f7182e7	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/resnet50_v1.onnx			2			Apache License, Version 2.0	MLPerf_ResNet50_v1.5	the output label	classification	1.0
89	2022-02-03 17:48:14.731903+00	2022-02-03 17:48:14.731903+00	\N			CNN	Yen-Hsiang Chang	COCO 2017	MLPerf_SSD_ResNet34_1200x1200.\n	b70fc6c72bc9349981f3b1258f31bc87	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/resnet34-ssd1200.onnx			2			Apache License, Version 2.0	MLPerf_SSD_ResNet34_1200x1200	the output bounding box	boundingbox	1.0
90	2022-02-03 17:48:14.736954+00	2022-02-03 17:48:14.736954+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the MobileNet publication. This model expects mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 300. The images have to be loaded in to a range of [0, 255] and then normalized using mean = [127, 127, 127] and std = [128, 128, 128]\n	ac33959f371eaed1be866499af3b2894	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/mb2-ssd-lite.onnx			2			unrestricted	MobileNet_SSD_Lite_v2.0	the output bounding box	boundingbox	1.0
91	2022-02-03 17:48:14.741755+00	2022-02-03 17:48:14.741755+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the MobileNet publication. This model expects mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 300. The images have to be loaded in to a range of [0, 255] and then normalized using mean = [127, 127, 127] and std = [128, 128, 128]\n	16dff9e111042f981b2c054c6f74f85f	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/mb1-ssd.onnx			2			unrestricted	MobileNet_SSD_v1.0	the output bounding box	boundingbox	1.0
92	2022-02-03 17:48:14.745725+00	2022-02-03 17:48:14.745725+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 331. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	7e96b0856877acb50471fc2d1f0e23b4	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/nasnetalarge-imagenet.onnx			2			unrestricted	NasNet_A_Large	the output label	classification	1.0
93	2022-02-03 17:48:14.74998+00	2022-02-03 17:48:14.74998+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	81629351ceba9ced67754312d7dae47d	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/nasnetamobile-imagenet.onnx			2			unrestricted	NasNet_A_Mobile	the output label	classification	1.0
94	2022-02-03 17:48:14.754245+00	2022-02-03 17:48:14.754245+00	\N			CNN	Yen-Hsiang Chang	COCO 2017	This model is a real-time neural network for object instance segmentation that detects 80 different classes. This model only allows batchsize = 1 currently.\n	ba1088fe5c4a9182075f3ce136037968	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/onnxvision_mask_rcnn_r_50_fpn.onnx			2			unrestricted	OnnxVision_Mask_RCNN_R_50_FPN	the output instance segment	instancesegment	1.0
95	2022-02-03 17:48:14.758287+00	2022-02-03 17:48:14.758287+00	\N			CNN	Yen-Hsiang Chang	COCO 2017	This model is the Single Stage Detector in onnx vision All pre-trained models expect input images normalized in the same way, i.e. 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 1200. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225] This model only allows batchsize = 1 currently.\n	c87961aa865330bbb6eab9687ae2496c	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/onnxvision_ssd.onnx			2			unrestricted	OnnxVision_SSD	the output bounding box	boundingbox	1.0
96	2022-02-03 17:48:14.762629+00	2022-02-03 17:48:14.762629+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 331. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	c652ab5d706bcf3bed98fc8d50b877d1	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/pnasnet5large-imagenet.onnx			2			unrestricted	PNasNet_5_Large	the output label	classification	1.0
97	2022-02-03 17:48:14.76669+00	2022-02-03 17:48:14.76669+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 331. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	320070d5e8cde63ae577daf3d9dceb1c	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/polynet-imagenet.onnx			2			unrestricted	PolyNet	the output label	classification	1.0
98	2022-02-03 17:48:14.771082+00	2022-02-03 17:48:14.771082+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	d1685cbf522dc6f9d22fb92332e9b698	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/resnext101_32x4d-imagenet.onnx			2			unrestricted	ResNext_101_32x4D	the output label	classification	1.0
99	2022-02-03 17:48:14.775329+00	2022-02-03 17:48:14.775329+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	0e3d0b2b3896d8edb1f394cf0c7bf2b2	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/resnext101_64x4d-imagenet.onnx			2			unrestricted	ResNext_101_64x4D	the output label	classification	1.0
100	2022-02-03 17:48:14.779529+00	2022-02-03 17:48:14.779529+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	1016faf78402719b45f86b4e7d2dc105	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/se_resnet101-imagenet.onnx			2			unrestricted	SE_ResNet_101	the output label	classification	1.0
101	2022-02-03 17:48:14.783753+00	2022-02-03 17:48:14.783753+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	e6526ad541c289e9de9d87546ce1fd8b	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/se_resnet152-imagenet.onnx			2			unrestricted	SE_ResNet_152	the output label	classification	1.0
102	2022-02-03 17:48:14.787769+00	2022-02-03 17:48:14.787769+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	132b3cf809c7f7ddfbc69a2a480e14b5	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/se_resnet50-imagenet.onnx			2			unrestricted	SE_ResNet_50	the output label	classification	1.0
103	2022-02-03 17:48:14.792331+00	2022-02-03 17:48:14.792331+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	58cf591e3e457cb4dfc98d2facc7f732	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/se_resnext101_32x4d-imagenet.onnx			2			unrestricted	SE_ResNext_101_32x4D	the output label	classification	1.0
104	2022-02-03 17:48:14.797068+00	2022-02-03 17:48:14.797068+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	fd3adc82ce4bbf683ddadfee846e2f65	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/se_resnext50_32x4d-imagenet.onnx			2			unrestricted	SE_ResNext_50_32x4D	the output label	classification	1.0
105	2022-02-03 17:48:14.80191+00	2022-02-03 17:48:14.80191+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	c652ab5d706bcf3bed98fc8d50b877d1	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/senet154-imagenet.onnx			2			unrestricted	SENet_154	the output label	classification	1.0
106	2022-02-03 17:48:14.806485+00	2022-02-03 17:48:14.806485+00	\N			CNN	Yen-Hsiang Chang	VOC	This model is a replication of the model described in the SRGAN publication.\n	4527947ddf80f3da2bc9a216b6fb813b	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/srgan.onnx			2			unrestricted	SRGAN	the output image	image	1.0
107	2022-02-03 17:48:14.811483+00	2022-02-03 17:48:14.811483+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the AlexNet publication. The model is generated using torch.onnx based on the torchvision model All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	1fa49494d4b1c24a0ee5e871930343de	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_alexnet.onnx			2			unrestricted	TorchVision_AlexNet	the output label	classification	1.0
108	2022-02-03 17:48:14.81628+00	2022-02-03 17:48:14.81628+00	\N			CNN	Yen-Hsiang Chang	COCO 2017	The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225].\n	7ab5a923c5b4f673fd54ec863a3da1c5	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_deeplabv3_resnet101.onnx			2			unrestricted	TorchVision_DeepLabv3_Resnet101	the output semantic segment	semanticsegment	1.0
109	2022-02-03 17:48:14.82095+00	2022-02-03 17:48:14.82095+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	811de9078d1c8a84b6764362fe77d7f0	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_densenet121.onnx			2			unrestricted	TorchVision_DenseNet_121	the output label	classification	1.0
110	2022-02-03 17:48:14.826395+00	2022-02-03 17:48:14.826395+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	e4cc70e582678ec4e8ae358c53394f0f	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_densenet161.onnx			2			unrestricted	TorchVision_DenseNet_161	the output label	classification	1.0
111	2022-02-03 17:48:14.831142+00	2022-02-03 17:48:14.831142+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	66b0c9eb4f98360dc33f31d882fa0dce	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_densenet169.onnx			2			unrestricted	TorchVision_DenseNet_169	the output label	classification	1.0
112	2022-02-03 17:48:14.835719+00	2022-02-03 17:48:14.835719+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	52cb6ceff5c2e931de1721f855a2b239	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_densenet201.onnx			2			unrestricted	TorchVision_DenseNet_201	the output label	classification	1.0
113	2022-02-03 17:48:14.840534+00	2022-02-03 17:48:14.840534+00	\N			CNN	Yen-Hsiang Chang	COCO 2017	The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225].\n	4b24503a089adba2d10b296adf760c87	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_fcn_resnet101.onnx			2			unrestricted	TorchVision_FCN_Resnet101	the output semantic segment	semanticsegment	1.0
114	2022-02-03 17:48:14.845383+00	2022-02-03 17:48:14.845383+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	fa2b1000e97cd16bad07a502f58ece5c	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_resnet101.onnx			2			unrestricted	TorchVision_ResNet_101	the output label	classification	1.0
178	2022-02-03 17:48:15.172394+00	2022-02-03 17:48:15.172394+00	\N			CTR	Cheng Li		AI Matrix DIEN.\n	7be74fc1c1eb4ace05aed4547dfd7e89	DIEN.pb			4			unrestricted	AI_Matrix_DIEN	the output	raw	1.0
115	2022-02-03 17:48:14.850202+00	2022-02-03 17:48:14.850202+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	4b750e31e1b3973d76816fc0a5919cb5	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_resnet152.onnx			2			unrestricted	TorchVision_ResNet_152	the output label	classification	1.0
116	2022-02-03 17:48:14.855184+00	2022-02-03 17:48:14.855184+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	e3faa3710ee19e81c8c1b07e04e2ed7f	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_resnet18.onnx			2			unrestricted	TorchVision_ResNet_18	the output label	classification	1.0
117	2022-02-03 17:48:14.859991+00	2022-02-03 17:48:14.859991+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	3395fe6af20cd222d92a6989454973d4	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_resnet34.onnx			2			unrestricted	TorchVision_ResNet_34	the output label	classification	1.0
118	2022-02-03 17:48:14.865208+00	2022-02-03 17:48:14.865208+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	5b48facd960761ac090c5977957fc416	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_resnet50.onnx			2			unrestricted	TorchVision_ResNet_50	the output label	classification	1.0
119	2022-02-03 17:48:14.869998+00	2022-02-03 17:48:14.869998+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	b1d4e11c2d31dad1e17770b49a3d6a30	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_squeezenet1_0.onnx			2			unrestricted	TorchVision_SqueezeNet_v1.0	the output label	classification	1.0
120	2022-02-03 17:48:14.874838+00	2022-02-03 17:48:14.874838+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	c124ba759a39a627e0923be8e83cd4ab	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_squeezenet1_1.onnx			2			unrestricted	TorchVision_SqueezeNet_v1.1	the output label	classification	1.0
121	2022-02-03 17:48:14.879887+00	2022-02-03 17:48:14.879887+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	44a6ad9b498c903d08216281872c38cf	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg11.onnx			2			unrestricted	TorchVision_VGG_11	the output label	classification	1.0
122	2022-02-03 17:48:14.884955+00	2022-02-03 17:48:14.884955+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	7a2d61adf621185e5c2605c5091f974c	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg11_bn.onnx			2			unrestricted	TorchVision_VGG_11_BN	the output label	classification	1.0
123	2022-02-03 17:48:14.890594+00	2022-02-03 17:48:14.890594+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	f8dc46560866f5267c8b14ab93ae096e	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg13.onnx			2			unrestricted	TorchVision_VGG_13	the output label	classification	1.0
124	2022-02-03 17:48:14.895768+00	2022-02-03 17:48:14.895768+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	5bc05c3b0b35e0d082c199cf7d511acd	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg13_bn.onnx			2			unrestricted	TorchVision_VGG_13_BN	the output label	classification	1.0
125	2022-02-03 17:48:14.900826+00	2022-02-03 17:48:14.900826+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	e104cbcef280629aa230c556821dc4f6	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg16.onnx			2			unrestricted	TorchVision_VGG_16	the output label	classification	1.0
179	2022-02-03 17:48:15.176534+00	2022-02-03 17:48:15.176534+00	\N	70.01	89.29	CNN	Cheng Li	ImageNet	AI Matrix GoogleNet.\n	6efe5eb229bfd1d1e28cd2c42f927167	GoogleNet-NCWH.pb			4			unrestricted	AI_Matrix_GoogleNet	the output label	classification	1.0
126	2022-02-03 17:48:14.905938+00	2022-02-03 17:48:14.905938+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	be4e4246df2293e3102dd2d742b0f6c3	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg16_bn.onnx			2			unrestricted	TorchVision_VGG_16_BN	the output label	classification	1.0
127	2022-02-03 17:48:14.911375+00	2022-02-03 17:48:14.911375+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	5082bb6a5720311febce81de4aa355c7	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg19.onnx			2			unrestricted	TorchVision_VGG_19	the output label	classification	1.0
128	2022-02-03 17:48:14.916211+00	2022-02-03 17:48:14.916211+00	\N			CNN	Yen-Hsiang Chang	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	7a5a8c9da5d248473e9e81e7238dd169	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/torchvision_vgg19_bn.onnx			2			unrestricted	TorchVision_VGG_19_BN	the output label	classification	1.0
129	2022-02-03 17:48:14.921084+00	2022-02-03 17:48:14.921084+00	\N			CNN	Yen-Hsiang Chang	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 229. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	608d5b80fd6119e5ec19b3dd3d217167	https://s3.amazonaws.com/store.carml.org/models/onnxruntime/xception-imagenet.onnx			2			unrestricted	Xception	the output label	classification	1.0
130	2022-02-03 17:48:14.927726+00	2022-02-03 17:48:14.927726+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the Resnet publication originally written in Caffe. The pre-trained model expects input in mini-batches of 3-channel BGR images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 255] and then normalized using mean = [102.9801, 115.9465, 122.7717] and std = [1, 1, 1]\n	656bf13acb441b4427377acec10bb3e0	https://s3.amazonaws.com/store.carml.org/models/pytorch/cafferesnet101-imagenet.pt			3			unrestricted	Caffe_ResNet_101	the output label	classification	1.0
131	2022-02-03 17:48:14.933946+00	2022-02-03 17:48:14.933946+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	d9c9b48f61a035ea2fa05c1fee44cc72	https://s3.amazonaws.com/store.carml.org/models/pytorch/dpn107-imagenet.pt			3			unrestricted	DPN_107	the output label	classification	1.0
132	2022-02-03 17:48:14.939076+00	2022-02-03 17:48:14.939076+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	f842d8fdbfa37ec5a1c931815d469585	https://s3.amazonaws.com/store.carml.org/models/pytorch/dpn131-imagenet.pt			3			unrestricted	DPN_131	the output label	classification	1.0
133	2022-02-03 17:48:14.944033+00	2022-02-03 17:48:14.944033+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	6287a2d68054975d4d3c82c71742eb21	https://s3.amazonaws.com/store.carml.org/models/pytorch/dpn68-imagenet.pt			3			unrestricted	DPN_68_v1.0	the output label	classification	1.0
134	2022-02-03 17:48:14.94981+00	2022-02-03 17:48:14.94981+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	91d59a7c160c162748dba89b35690bd7	https://s3.amazonaws.com/store.carml.org/models/pytorch/dpn68b-imagenet.pt			3			unrestricted	DPN_68_v2.0	the output label	classification	1.0
135	2022-02-03 17:48:14.954487+00	2022-02-03 17:48:14.954487+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	58513bd1ae35f120f305eed840734ad1	https://s3.amazonaws.com/store.carml.org/models/pytorch/dpn92-imagenet.pt			3			unrestricted	DPN_92	the output label	classification	1.0
136	2022-02-03 17:48:14.959404+00	2022-02-03 17:48:14.959404+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the Dual Path Networks publication. The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [124 / 255, 117 / 255, 104 / 255] and std = [1 / (.0167 * 255), 1 / (.0167 * 255), 1 / (.0167 * 255)]\n	6806745213fcd7bf0eec71bfe69d88df	https://s3.amazonaws.com/store.carml.org/models/pytorch/dpn98-imagenet.pt			3			unrestricted	DPN_98	the output label	classification	1.0
137	2022-02-03 17:48:14.964088+00	2022-02-03 17:48:14.964088+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 299. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	5643b8cdce7ea7aed18a7e5f3960cb3b	https://s3.amazonaws.com/store.carml.org/models/pytorch/inceptionresnetv2-imagenet.pt			3			unrestricted	Inception_ResNet_v2.0	the output label	classification	1.0
138	2022-02-03 17:48:14.968962+00	2022-02-03 17:48:14.968962+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 299. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	f0372bbb562d22e64815ad84387776ce	https://s3.amazonaws.com/store.carml.org/models/pytorch/inceptionv3-imagenet.pt			3			unrestricted	Inception_v3.0	the output label	classification	1.0
139	2022-02-03 17:48:14.973698+00	2022-02-03 17:48:14.973698+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the MobileNet publication. This model expects mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 300. The images have to be loaded in to a range of [0, 255] and then normalized using mean = [127, 127, 127] and std = [128, 128, 128]\n	31107eb8bc8bdc40bd663f8bddce0ebb	https://s3.amazonaws.com/store.carml.org/models/pytorch/mb2-ssd-lite.pt			3			unrestricted	MobileNet_SSD_Lite_v2.0	the output label	boundingbox	1.0
140	2022-02-03 17:48:14.978647+00	2022-02-03 17:48:14.978647+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the MobileNet publication. This model expects mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 300. The images have to be loaded in to a range of [0, 255] and then normalized using mean = [127, 127, 127] and std = [128, 128, 128]\n	83ce8910a6a502456a5033c3509fc6d2	https://s3.amazonaws.com/store.carml.org/models/pytorch/mb1-ssd.pt			3			unrestricted	MobileNet_SSD_v1.0	the output bounding box	boundingbox	1.0
141	2022-02-03 17:48:14.983381+00	2022-02-03 17:48:14.983381+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 331. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	b82361909cae3a7da7cd0bfc18125eab	https://s3.amazonaws.com/store.carml.org/models/pytorch/nasnetalarge-imagenet.pt			3			unrestricted	NasNet_A_Large	the output label	classification	1.0
142	2022-02-03 17:48:14.988339+00	2022-02-03 17:48:14.988339+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	0a26aed51897cad244f2aa542e7c1e3c	https://s3.amazonaws.com/store.carml.org/models/pytorch/nasnetamobile-imagenet.pt			3			unrestricted	NasNet_A_Mobile	the output label	classification	1.0
143	2022-02-03 17:48:14.993709+00	2022-02-03 17:48:14.993709+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 331. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	07bc0bc89e1127c153de8cb8f77d0972	https://s3.amazonaws.com/store.carml.org/models/pytorch/pnasnet5large-imagenet.pt			3			unrestricted	PNasNet_5_Large	the output label	classification	1.0
144	2022-02-03 17:48:14.998499+00	2022-02-03 17:48:14.998499+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 331. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	d17f09bddd7f166895c0bfdb293c3622	https://s3.amazonaws.com/store.carml.org/models/pytorch/polynet-imagenet.pt			3			unrestricted	PolyNet	the output label	classification	1.0
145	2022-02-03 17:48:15.012339+00	2022-02-03 17:48:15.012339+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	883ebb742cb6b0b93f3c5b2de65ecc5a	https://s3.amazonaws.com/store.carml.org/models/pytorch/resnext101_32x4d-imagenet.pt			3			unrestricted	ResNext101_32x4D	the output label	classification	1.0
146	2022-02-03 17:48:15.01756+00	2022-02-03 17:48:15.01756+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	036f4013faa486c53413657148c96281	https://s3.amazonaws.com/store.carml.org/models/pytorch/resnext101_64x4d-imagenet.pt			3			unrestricted	ResNext101_64x4D	the output label	classification	1.0
147	2022-02-03 17:48:15.022632+00	2022-02-03 17:48:15.022632+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	941ac83601681306e652d76bec5966f8	https://s3.amazonaws.com/store.carml.org/models/pytorch/se_resnet101-imagenet.pt			3			unrestricted	SE_ResNet_101	the output label	classification	1.0
148	2022-02-03 17:48:15.027456+00	2022-02-03 17:48:15.027456+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	0f882b314c663ee64edaf201beda5175	https://s3.amazonaws.com/store.carml.org/models/pytorch/se_resnet152-imagenet.pt			3			unrestricted	SE_ResNet_152	the output label	classification	1.0
149	2022-02-03 17:48:15.032283+00	2022-02-03 17:48:15.032283+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	59d9439414448bc644238eb27ce94e7a	https://s3.amazonaws.com/store.carml.org/models/pytorch/se_resnet50-imagenet.pt			3			unrestricted	SE_ResNet_50	the output label	classification	1.0
150	2022-02-03 17:48:15.037259+00	2022-02-03 17:48:15.037259+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	353df39873bd70397591f5e68dfff8cb	https://s3.amazonaws.com/store.carml.org/models/pytorch/se_resnext101_32x4d-imagenet.pt			3			unrestricted	SE_ResNext_101_32x4D	the output label	classification	1.0
151	2022-02-03 17:48:15.042666+00	2022-02-03 17:48:15.042666+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	34dc3df9301edc3c4583300587a67ed9	https://s3.amazonaws.com/store.carml.org/models/pytorch/se_resnext50_32x4d-imagenet.pt			3			unrestricted	SE_ResNext_50_32x4D	the output label	classification	1.0
152	2022-02-03 17:48:15.048549+00	2022-02-03 17:48:15.048549+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	989c3a72ebaf30596b3b8bf6488180ac	https://s3.amazonaws.com/store.carml.org/models/pytorch/senet154-imagenet.pt			3			unrestricted	SENet_154	the output label	classification	1.0
153	2022-02-03 17:48:15.053828+00	2022-02-03 17:48:15.053828+00	\N			CNN	abduld	VOC	This model is a replication of the model described in the SRGAN publication.\n	2ea83f6e74420f60902e074fb0e893df	https://s3.amazonaws.com/store.carml.org/models/pytorch/srgan_netG_epoch_4_100.pt			3			unrestricted	SRGAN_v1.0	the output image	image	1.0
154	2022-02-03 17:48:15.058865+00	2022-02-03 17:48:15.058865+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the AlexNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	50a8a0f7cb9c3caa8f50a89b59a820a9	https://s3.amazonaws.com/store.carml.org/models/pytorch/alexnet.pt			3			unrestricted	TorchVision_AlexNet	the output label	classification	1.0
155	2022-02-03 17:48:15.064859+00	2022-02-03 17:48:15.064859+00	\N			CNN	Yen-Hsiang Chang	COCO 2017	The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225].\n	8adc41a27060bfadfe6fcde02dff59a0	https://s3.amazonaws.com/store.carml.org/models/pytorch/deeplabv3_resnet101.pt			3			unrestricted	TorchVision_DeepLabv3_Resnet101	the output semantic segment	semanticsegment	1.0
156	2022-02-03 17:48:15.068342+00	2022-02-03 17:48:15.068342+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	bae13d1824d4b2d8bb1f99bf83e0bbd4	https://s3.amazonaws.com/store.carml.org/models/pytorch/densenet121.pt			3			unrestricted	TorchVision_DenseNet_121	the output label	classification	1.0
157	2022-02-03 17:48:15.072158+00	2022-02-03 17:48:15.072158+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	97ce2d83f49bede95e16bede0f9905f5	https://s3.amazonaws.com/store.carml.org/models/pytorch/densenet161.pt			3			unrestricted	TorchVision_DenseNet_161	the output label	classification	1.0
158	2022-02-03 17:48:15.076482+00	2022-02-03 17:48:15.076482+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	b6a86beb5d9932890a3e06a46f953b3a	https://s3.amazonaws.com/store.carml.org/models/pytorch/densenet169.pt			3			unrestricted	TorchVision_DenseNet_169	the output label	classification	1.0
159	2022-02-03 17:48:15.080894+00	2022-02-03 17:48:15.080894+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the DenseNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	012c4edd769bc9444d8037fb5f789832	https://s3.amazonaws.com/store.carml.org/models/pytorch/densenet201.pt			3			unrestricted	TorchVision_DenseNet_201	the output label	classification	1.0
160	2022-02-03 17:48:15.084851+00	2022-02-03 17:48:15.084851+00	\N			CNN	Yen-Hsiang Chang	COCO 2017	The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225].\n	5e0b3d0a594d561a566e792a79da93c9	https://s3.amazonaws.com/store.carml.org/models/pytorch/fcn_resnet101.pt			3			unrestricted	TorchVision_Fcn_Resnet101	the output semantic segment	semanticsegment	1.0
161	2022-02-03 17:48:15.089377+00	2022-02-03 17:48:15.089377+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	c4b6541bbcea329ccd7fd5bbb72733df	https://s3.amazonaws.com/store.carml.org/models/pytorch/resnet101.pt			3			unrestricted	TorchVision_ResNet_101	the output label	classification	1.0
162	2022-02-03 17:48:15.099307+00	2022-02-03 17:48:15.099307+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	2de9bc1451c96ba566a275c9082c37d8	https://s3.amazonaws.com/store.carml.org/models/pytorch/resnet152.pt			3			unrestricted	TorchVision_ResNet_152	the output label	classification	1.0
163	2022-02-03 17:48:15.104036+00	2022-02-03 17:48:15.104036+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	1664b51cd7e6595d545e9cfad38987da	https://s3.amazonaws.com/store.carml.org/models/pytorch/resnet18.pt			3			unrestricted	TorchVision_ResNet_18	the output label	classification	1.0
164	2022-02-03 17:48:15.108274+00	2022-02-03 17:48:15.108274+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	0997634a4d13c3a809057e79c563dc5e	https://s3.amazonaws.com/store.carml.org/models/pytorch/resnet34.pt			3			unrestricted	TorchVision_ResNet_34	the output label	classification	1.0
165	2022-02-03 17:48:15.112579+00	2022-02-03 17:48:15.112579+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	0aea66ce0fe0e27497ff1b82c0a2f925	https://s3.amazonaws.com/store.carml.org/models/pytorch/resnet50.pt			3			unrestricted	TorchVision_ResNet_50	the output label	classification	1.0
166	2022-02-03 17:48:15.117258+00	2022-02-03 17:48:15.117258+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	0cf61de39de571df51373b5ea52a8352	https://s3.amazonaws.com/store.carml.org/models/pytorch/squeezenet1_0.pt			3			unrestricted	TorchVision_SqueezeNet_v1.0	the output label	classification	1.0
167	2022-02-03 17:48:15.121815+00	2022-02-03 17:48:15.121815+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the ResNet publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	7cc2886d7d7b88c62fa34cfebd7d55ff	https://s3.amazonaws.com/store.carml.org/models/pytorch/squeezenet1_1.pt			3			unrestricted	TorchVision_SqueezeNet_v1.1	the output label	classification	1.0
168	2022-02-03 17:48:15.125817+00	2022-02-03 17:48:15.125817+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	07523ccdc0d8cfed64c79ef0a0acd8ba	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg11.pt			3			unrestricted	TorchVision_VGG_11	the output label	classification	1.0
169	2022-02-03 17:48:15.130502+00	2022-02-03 17:48:15.130502+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	105a37baa5cf89ab8d0ca866dfa5b66e	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg11_bn.pt			3			unrestricted	TorchVision_VGG_11_BN	the output label	classification	1.0
170	2022-02-03 17:48:15.13469+00	2022-02-03 17:48:15.13469+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	f84b60fdb920f5917bcdaa607d147bdd	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg13.pt			3			unrestricted	TorchVision_VGG_13	the output label	classification	1.0
171	2022-02-03 17:48:15.138648+00	2022-02-03 17:48:15.138648+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	af5f5a23877ceab4783fc0580092c3f7	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg13_bn.pt			3			unrestricted	TorchVision_VGG_13_BN	the output label	classification	1.0
172	2022-02-03 17:48:15.146413+00	2022-02-03 17:48:15.146413+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	09bf5984508443e87aa7e680b9e52d76	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg16.pt			3			unrestricted	TorchVision_VGG_16	the output label	classification	1.0
173	2022-02-03 17:48:15.150793+00	2022-02-03 17:48:15.150793+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	ebe2f07740d819e74bdf3ffcb68780fe	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg16_bn.pt			3			unrestricted	TorchVision_VGG_16_BN	the output label	classification	1.0
174	2022-02-03 17:48:15.155146+00	2022-02-03 17:48:15.155146+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	0cfdb98cb02ce5a727ea6c688127122d	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg19.pt			3			unrestricted	TorchVision_VGG_19	the output label	classification	1.0
175	2022-02-03 17:48:15.1592+00	2022-02-03 17:48:15.1592+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the VGG publication. All pre-trained models expect input images normalized in the same way, i.e. mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be at least 224. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]\n	7438737efb01d6b1c410cae4a2efd14d	https://s3.amazonaws.com/store.carml.org/models/pytorch/vgg19_bn.pt			3			unrestricted	TorchVision_VGG_19_BN	the output label	classification	1.0
176	2022-02-03 17:48:15.163137+00	2022-02-03 17:48:15.163137+00	\N			CNN	abduld	ImageNet	The pre-trained model expects input in mini-batches of 3-channel RGB images of shape (3 x H x W), where H and W are expected to be 229. The images have to be loaded in to a range of [0, 1] and then normalized using mean = [0.5, 0.5, 0.5] and std = [0.5, 0.5, 0.5]\n	c1fd34618d69e408a7517467c89d0147	https://s3.amazonaws.com/store.carml.org/models/pytorch/xception-imagenet.pt			3			unrestricted	Xception	the output label	classification	1.0
180	2022-02-03 17:48:15.180297+00	2022-02-03 17:48:15.180297+00	\N	75.93	93.00	CNN	Cheng Li	ImageNet	AI Matrix ResNet152.\n	f3c0052de27ebfee8795d01755667f23	Resnet152-NCWH.pb			4			unrestricted	AI_Matrix_ResNet152	the output label	classification	1.0
181	2022-02-03 17:48:15.184213+00	2022-02-03 17:48:15.184213+00	\N	74.38	91.97	CNN	Cheng Li	ImageNet	AI Matrix ResNet50.\n	8c17158225e976abc0c06100e095c113	Resnet50-NCWH.pb			4			unrestricted	AI_Matrix_ResNet50	the output label	classification	1.0
182	2022-02-03 17:48:15.188742+00	2022-02-03 17:48:15.188742+00	\N			CNN	abduld	ImageNet	This model is a replication of the model described in the AlexNet publication. Differences: not training with the relighting data-augmentation; initializing non-zero biases to 0.1 instead of 1 (found necessary for training, as initialization to 1 gave flat loss). The bundled model is the iteration 360,000 snapshot. The best validation performance during training was iteration 358,000 with validation accuracy 57.258% and loss 1.83948. This model obtains a top-1 accuracy 57.1% and a top-5 accuracy 80.2% on the validation set, using just the center crop. (Using the average of 10 crops, (4 + 1 center) * 2 mirror, should obtain a bit higher accuracy.) This model was trained by Evan Shelhamer @shelhamer\n	6d23f40191c1dcac71285f41a85abd8e	bvlc_alexnet_1.0/frozen_model.pb			4			unrestricted	BVLC_AlexNet_Caffe	the output label	classification	1.0
183	2022-02-03 17:48:15.193064+00	2022-02-03 17:48:15.193064+00	\N			CNN	Cheng Li	ImageNet	This model is a replication of the model described in the GoogleNet publication. We would like to thank Christian Szegedy for all his help in the replication of GoogleNet model. Differences: not training with the relighting data-augmentation; not training with the scale or aspect-ratio data-augmentation; uses "xavier" to initialize the weights instead of "gaussian"; quick_solver.prototxt uses a different learning rate decay policy than the original solver.prototxt, that allows a much faster training (60 epochs vs 250 epochs); The bundled model is the iteration 2,400,000 snapshot (60 epochs) using quick_solver.prototxt This bundled model obtains a top-1 accuracy 68.7% (31.3% error) and a top-5 accuracy 88.9% (11.1% error) on the validation set, using just the center crop. (Using the average of 10 crops, (4 + 1 center) * 2 mirror, should obtain a bit higher accuracy.) Timings for bvlc_googlenet with cuDNN using batch_size:128 on a K40c: Average Forward pass: 562.841 ms. Average Backward pass: 1123.84 ms. Average Forward-Backward: 1688.8 ms. This model was trained by Sergio Guadarrama @sguada\n	283087f6a9c25d851e581ea19944ff9d	bvlc_googlenet_1.0/frozen_model.pb			4			unrestricted	BVLC_GoogLeNet_Caffe	the output label	classification	1.0
184	2022-02-03 17:48:15.199237+00	2022-02-03 17:48:15.199237+00	\N			CNN	Jingning Tang	PASCAL VOC 2012	TensorFlow Semantic Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use deeplabv3_mnv2_dm05_pascal_train_aug(deeplabv3_mnv2_dm05_pascal_train_aug_2018_10_01) from TensorFlow DeepLab Model Zoo.\n	0336ceb67b378df8ada0efe9eadb5ac8	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/deeplabv3_mnv2_dm05_pascal_train_aug_2018_10_01/frozen_inference_graph.pb			4			Apache License, Version 2.0	DeepLabv3_MobileNet_v2_DM_05_PASCAL_VOC_Train_Aug	the output semantic segment	semanticsegment	1.0
185	2022-02-03 17:48:15.203667+00	2022-02-03 17:48:15.203667+00	\N			CNN	Jingning Tang	PASCAL VOC 2012	TensorFlow Semantic Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use deeplabv3_mnv2_dm05_pascal_trainval(deeplabv3_mnv2_dm05_pascal_trainval_2018_10_01) from TensorFlow DeepLab Model Zoo.\n	a2337e2840c4d4bbab005b519fc5c43e	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/deeplabv3_mnv2_dm05_pascal_trainval_2018_10_01/frozen_inference_graph.pb			4			Apache License, Version 2.0	DeepLabv3_MobileNet_v2_DM_05_PASCAL_VOC_Train_Val	the output semantic segment	semanticsegment	1.0
186	2022-02-03 17:48:15.20788+00	2022-02-03 17:48:15.20788+00	\N			CNN	Cheng Li	PASCAL VOC 2012	TensorFlow Semantic Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use mobilenetv2_coco_voc_trainaug(deeplabv3_mnv2_pascal_train_aug_2018_01_29) from TensorFlow DeepLab Model Zoo.\n	b0a1d0340189d7003291010abbc2e475	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/deeplabv3_mnv2_pascal_train_aug_2018_01_29/frozen_inference_graph.pb			4			Apache License, Version 2.0	DeepLabv3_MobileNet_v2_PASCAL_VOC_Train_Aug	the output semantic segment	semanticsegment	1.0
187	2022-02-03 17:48:15.212024+00	2022-02-03 17:48:15.212024+00	\N			CNN	Cheng Li	PASCAL VOC 2012	TensorFlow Semantic Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use mobilenetv2_coco_voc_trainval(deeplabv3_mnv2_pascal_trainval_2018_01_29) from TensorFlow DeepLab Model Zoo.\n	bfc503739d93cedf973f82a5df1901eb	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/deeplabv3_mnv2_pascal_trainval_2018_01_29/frozen_inference_graph.pb			4			Apache License, Version 2.0	DeepLabv3_MobileNet_v2_PASCAL_VOC_Train_Val	the output semantic segment	semanticsegment	1.0
188	2022-02-03 17:48:15.216189+00	2022-02-03 17:48:15.216189+00	\N			CNN	Jingning Tang	PASCAL VOC 2012	TensorFlow Semantic Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use deeplabv3_pascal_train_aug(deeplabv3_pascal_train_aug_2018_01_04) from TensorFlow DeepLab Model Zoo.\n	e6d2e7c8c9cf683e43ec052a5d8f62aa	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/deeplabv3_pascal_train_aug_2018_01_04/frozen_inference_graph.pb			4			Apache License, Version 2.0	DeepLabv3_Xception_65_PASCAL_VOC_Train_Aug	the output semantic segment	semanticsegment	1.0
189	2022-02-03 17:48:15.225059+00	2022-02-03 17:48:15.225059+00	\N			CNN	Jingning Tang	PASCAL VOC 2012	TensorFlow Semantic Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use deeplabv3_pascal_trainval(deeplabv3_pascal_trainval_2018_01_04) from TensorFlow DeepLab Model Zoo.\n	ab5108a6fc6824c9cda9090a19181ca6	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/deeplabv3_pascal_trainval_2018_01_04/frozen_inference_graph.pb			4			Apache License, Version 2.0	DeepLabv3_Xception_65_PASCAL_VOC_Train_Val	the output semantic segment	semanticsegment	1.0
190	2022-02-03 17:48:15.229773+00	2022-02-03 17:48:15.229773+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_inception_resnet_v2_atrous_coco_2018_01_28 from TensorFlow detection model zoo.\n	a7cba73fa2af9aa394658057adaf0f2d	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_inception_resnet_v2_atrous_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_Inception_ResNet_v2_Atrous_COCO	the output bounding box	boundingbox	1.0
191	2022-02-03 17:48:15.234062+00	2022-02-03 17:48:15.234062+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_inception_resnet_v2_atrous_lowproposals_coco_2018_01_28 from TensorFlow detection model zoo.\n	558d79ebf9b67164f412c841690aba8d	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_inception_resnet_v2_atrous_lowproposals_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_Inception_ResNet_v2_Atrous_Lowproposals_COCO	the output bounding box	boundingbox	1.0
192	2022-02-03 17:48:15.238124+00	2022-02-03 17:48:15.238124+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_inception_v2_coco_2018_01_28 from TensorFlow detection model zoo.\n	1f1902262c16c2d9acb9bc4f8a8c266f	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_inception_v2_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_Inception_v2_COCO	the output bounding box	boundingbox	1.0
193	2022-02-03 17:48:15.242314+00	2022-02-03 17:48:15.242314+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_nas_coco_2018_01_28 from TensorFlow detection model zoo.\n	3eb92f992d5781d61b1fa1067ce4b305	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_nas_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_NAS_COCO	the output bounding box	boundingbox	1.0
194	2022-02-03 17:48:15.246402+00	2022-02-03 17:48:15.246402+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_nas_lowproposals_coco_2018_01_28 from TensorFlow detection model zoo.\n	32d670b40441a358d03a33d3b2d85d36	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_nas_lowproposals_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_NAS_Lowproposals_COCO	the output bounding box	boundingbox	1.0
195	2022-02-03 17:48:15.250457+00	2022-02-03 17:48:15.250457+00	\N			CNN	Jingning	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_resnet101_coco_2018_01_28 from TensorFlow detection model zoo.\n	cbbd349318851ad33a92797db23c9972	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_resnet101_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_ResNet101_COCO	the output bounding box	boundingbox	1.0
196	2022-02-03 17:48:15.25497+00	2022-02-03 17:48:15.25497+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_resnet101_lowproposals_coco_2018_01_28 from TensorFlow detection model zoo.\n	e8cc341b4dbde7cf5650fd6480989dc0	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_resnet101_lowproposals_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_ResNet101_Lowproposals_COCO	the output bounding box	boundingbox	1.0
197	2022-02-03 17:48:15.258942+00	2022-02-03 17:48:15.258942+00	\N			CNN	Cheng Li	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_resnet50_coco_2018_01_28 from TensorFlow detection model zoo.\n	8b6edeb143566f830e35765438b452ff	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_resnet50_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_ResNet50_COCO	the output bounding box	boundingbox	1.0
198	2022-02-03 17:48:15.262799+00	2022-02-03 17:48:15.262799+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use faster_rcnn_resnet50_lowproposals_coco_2018_01_28 from TensorFlow detection model zoo.\n	dc38b8692f73d6985a2c638b41ca2f16	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/faster_rcnn_resnet50_lowproposals_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Faster_RCNN_Resnet50_Lowproposals_COCO	the output bounding box	boundingbox	1.0
199	2022-02-03 17:48:15.266698+00	2022-02-03 17:48:15.266698+00	\N			CNN	Cheng Li	ImageNet	This variant of the Inception model is easier to use for DeepDream and other imaging techniques. This is because it allows the input image to be any size, and the optimized images are also prettier. Inception 5h is equivalent to Inception V1.\n	be71c0d3ba9c5952b11656133588c75c	inception_5h.pb			4			unrestricted	Inception_5h	the output label	classification	1.0
200	2022-02-03 17:48:15.27055+00	2022-02-03 17:48:15.27055+00	\N	80.4	95.3	CNN	Cheng Li	ImageNet	Inception-ResNet-v2, a convolutional neural network (CNN) that achieves a new state of the art in terms of accuracy on the ILSVRC image classification benchmark. Inception-ResNet-v2 is a variation of our earlier Inception V3 model which borrows some ideas from Microsoft's ResNet papers. The full details of the model are in our arXiv preprint Inception-v4, Inception-ResNet and the Impact of Residual Connections on Learning.\n	ee6ad0ddd389b325832d4c4113103118	inception_resnet_v2_frozen.pb			4			unrestricted	Inception_ResNet_v2	the output label	classification	1.0
201	2022-02-03 17:48:15.274786+00	2022-02-03 17:48:15.274786+00	\N	69.8	89.6	CNN	Cheng Li	ImageNet	Inception v1 architecture, implemented in the winning ILSVRC 2014 submission GoogLeNet. Intorduced in Going deeper with convolutions, Szegedy et al. (2014) This model is from TensorFlow Models Slim (inception_v1_2016_08_28.tar.gz).\n	da5144c55d2fb47cfd1b80e177230269	inception_v1_frozen.pb			4			unrestricted	Inception_v1	the output label	classification	1.0
202	2022-02-03 17:48:15.278742+00	2022-02-03 17:48:15.278742+00	\N	73.9	91.8	CNN	Cheng Li	ImageNet	Inception-v2 introduced Factorization(factorize convolutions into smaller convolutions) and some minor change into Inception-v1. This model is from TensorFlow Models Slim (inception_v2_2016_08_28.tar.gz).\n	f357c54648189679b5c1af1df348d8cf	inception_v2_frozen.pb			4			TODO	Inception_v2	the output label	classification	1.0
203	2022-02-03 17:48:15.283061+00	2022-02-03 17:48:15.283061+00	\N	78.0	93.9	CNN	Cheng Li	ImageNet	variant of Inception-v2 which adds BN-auxiliary. This model is from TensorFlow Models Slim (inception_v3_2016_08_28.tar.gz).\n	328f68f37ae0c180191e96c9b73a813e	inception_v3_frozen.pb			4			unrestricted	Inception_v3	the output label	classification	1.0
204	2022-02-03 17:48:15.287118+00	2022-02-03 17:48:15.287118+00	\N	80.2	95.2	CNN	Cheng Li	ImageNet	This model is from TensorFlow Models Slim (inception_v4_2016_09_09.tar.gz).\n	3322bc1ca7f9cc753e6c70c2177319ac	inception_v4_frozen.pb			4			unrestricted	Inception_v4	the output label	classification	1.0
205	2022-02-03 17:48:15.291059+00	2022-02-03 17:48:15.291059+00	\N			CNN	Jingning Tang	COCO	TensorFlow Instance Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use mask_rcnn_inception_resnet_v2_atrous_coco_2018_01_28 from TensorFlow detection model zoo.\n	9dd24ee8716d34789efbf6b50c8f2ee1	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/mask_rcnn_inception_resnet_v2_atrous_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Mask_RCNN_Inception_ResNet_v2_Atrous_COCO	the output instance segment	instancesegment	1.0
206	2022-02-03 17:48:15.295071+00	2022-02-03 17:48:15.295071+00	\N			CNN	Cheng Li	COCO	TensorFlow Instance Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use mask_rcnn_inception_v2_coco_2018_01_28 from TensorFlow detection model zoo.\n	b47e443b313a709e4c39c1caeaa3ecb3	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/mask_rcnn_inception_v2_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Mask_RCNN_Inception_v2_COCO	the output instance segment	instancesegment	1.0
207	2022-02-03 17:48:15.299276+00	2022-02-03 17:48:15.299276+00	\N			CNN	Jingning Tang	COCO	TensorFlow Instance Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use mask_rcnn_resnet101_atrous_coco_2018_01_28 from TensorFlow detection model zoo.\n	0800f8fc9c40fd8a9caf89d608df5ae9	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/mask_rcnn_resnet101_atrous_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Mask_RCNN_ResNet101_v2_Atrous_COCO	the output instance segment	instancesegment	1.0
208	2022-02-03 17:48:15.303998+00	2022-02-03 17:48:15.303998+00	\N			CNN	Jingning Tang	COCO	TensorFlow Instance Segmentation model, which is trained on the COCO (Common Objects in Context) dataset. Use mask_rcnn_resnet50_atrous_coco_2018_01_28 from TensorFlow detection model zoo.\n	09d9045ce3b1eef50466b129c95543e8	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/mask_rcnn_resnet50_atrous_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	Mask_RCNN_ResNet50_v2_Atrous_COCO	the output instance segment	instancesegment	1.0
209	2022-02-03 17:48:15.308118+00	2022-02-03 17:48:15.308118+00	\N	71.23		CNN	Cheng Li	ImageNet	MLPerf_Mobilenet_v1_1.0_224. Use mobilenet_v1_2018_08_02/mobilenet_v1_1.0_224.tgz from TensorFlow detection model zoo.\n	d5f69cef81ad8afb335d9727a17c462a	mobilenet_v1_1.0_224_frozen.pb			4			Apache License, Version 2.0	MLPerf_Mobilenet_v1	the output label	classification	1.0
210	2022-02-03 17:48:15.313066+00	2022-02-03 17:48:15.313066+00	\N	76.16		CNN	Cheng Li	ImageNet	MLPerf_ResNet50_v1.5.\n	7b94a2da05dd30f6c0af23a46bc08886	resnet50_v1.pb			4			Apache License, Version 2.0	MLPerf_ResNet50_v1.5	the output label	classification	1.0
211	2022-02-03 17:48:15.317468+00	2022-02-03 17:48:15.317468+00	\N			CNN	Cheng Li	COCO	MLPerf_SSD_MobileNet_300x300. Use ssd_mobilenet_v1_coco_2018_01_28 from TensorFlow detection model zoo.\n	c9df908a779062ce00abe8f98e4a3eb1	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_mobilenet_v1_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	MLPerf_SSD_MobileNet_v1_300x300	the output bounding box	boundingbox	1.0
212	2022-02-03 17:48:15.321797+00	2022-02-03 17:48:15.321797+00	\N			CNN	Cheng Li	COCO	MLPerf_SSD_ResNet34_1200x1200.\n	2831b0a188efbb32c5e3e0c6cb6cc770	https://zenodo.org/record/3262269/files/ssd_resnet34_mAP_20.2.pb			4			Apache License, Version 2.0	MLPerf_SSD_ResNet34_1200x1200	the output bounding box	boundingbox	1.0
213	2022-02-03 17:48:15.326277+00	2022-02-03 17:48:15.326277+00	\N	41.5	66.3	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	0fdca2e0ef5a760143da81bca3bb504f	mobilenet_v1_0.25_128_frozen.pb			4			unrestricted	MobileNet_v1_0.25_128	the output label	classification	1.0
214	2022-02-03 17:48:15.330779+00	2022-02-03 17:48:15.330779+00	\N	39.5	64.4	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	f2f15e647262bb62f80a870b82f6c490	mobilenet_v1_0.25_128_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.25_128_Quant	the output label	classification	1.0
215	2022-02-03 17:48:15.335318+00	2022-02-03 17:48:15.335318+00	\N	45.5	70.3	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	156f268e686210a122dd457c82399d63	mobilenet_v1_0.25_160_frozen.pb			4			unrestricted	MobileNet_v1_0.25_160	the output label	classification	1.0
216	2022-02-03 17:48:15.339635+00	2022-02-03 17:48:15.339635+00	\N	43.4	68.5	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	b14242d4c7b83b60bb1564adf47d5572	mobilenet_v1_0.25_160_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.25_160_Quant	the output label	classification	1.0
217	2022-02-03 17:48:15.344429+00	2022-02-03 17:48:15.344429+00	\N	47.7	72.3	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	ffea6fa6911f807537239e4b0a784609	mobilenet_v1_0.25_192_frozen.pb			4			unrestricted	MobileNet_v1_0.25_192	the output label	classification	1.0
218	2022-02-03 17:48:15.34905+00	2022-02-03 17:48:15.34905+00	\N	46.	71.2	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	5f92d6bf03f102a0c8e5bc4c21f6ff6d	mobilenet_v1_0.25_192_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.25_192_Quant	the output label	classification	1.0
219	2022-02-03 17:48:15.353894+00	2022-02-03 17:48:15.353894+00	\N	49.8	74.2	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	865822137db139d1cc27570f7977e84c	mobilenet_v1_0.25_224_frozen.pb			4			unrestricted	MobileNet_v1_0.25_224	the output label	classification	1.0
220	2022-02-03 17:48:15.358303+00	2022-02-03 17:48:15.358303+00	\N	48.	72.8	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	374974e4565ae11ffdfc593e2367ccbd	mobilenet_v1_0.25_224_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.25_224_Quant	the output label	classification	1.0
221	2022-02-03 17:48:15.363136+00	2022-02-03 17:48:15.363136+00	\N	56.3	79.4	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	882a6d44a4c860fbf4cdaff45230983d	mobilenet_v1_0.5_128_frozen.pb			4			unrestricted	MobileNet_v1_0.5_128	the output label	classification	1.0
222	2022-02-03 17:48:15.368526+00	2022-02-03 17:48:15.368526+00	\N	54.5	77.7	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	def62267e4e781b0ad18613951580b2f	mobilenet_v1_0.5_128_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.5_128_Quant	the output label	classification	1.0
223	2022-02-03 17:48:15.372914+00	2022-02-03 17:48:15.372914+00	\N	59.1	81.9	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	f75fba66ae24dbb907dc4ea26cfb0674	mobilenet_v1_0.5_160_frozen.pb			4			unrestricted	MobileNet_v1_0.5_160	the output label	classification	1.0
224	2022-02-03 17:48:15.376689+00	2022-02-03 17:48:15.376689+00	\N	57.7	80.4	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	80890892120d884bb6283ba145f0a210	mobilenet_v1_0.5_160_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.5_160_Quant	the output label	classification	1.0
225	2022-02-03 17:48:15.380948+00	2022-02-03 17:48:15.380948+00	\N	61.7	83.6	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	fe41acaa04487cc35e2bf59a7cd8e5e4	mobilenet_v1_0.5_192_frozen.pb			4			unrestricted	MobileNet_v1_0.5_192	the output label	classification	1.0
226	2022-02-03 17:48:15.384951+00	2022-02-03 17:48:15.384951+00	\N	60.	82.2	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	f93309968626f91a8a2d5d19551313bb	mobilenet_v1_0.5_192_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.5_192_Quant	the output label	classification	1.0
227	2022-02-03 17:48:15.388652+00	2022-02-03 17:48:15.388652+00	\N	63.3	84.9	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	5f4f22e48c630d547401d988f3821f7d	mobilenet_v1_0.5_224_frozen.pb			4			unrestricted	MobileNet_v1_0.5_224	the output label	classification	1.0
228	2022-02-03 17:48:15.392446+00	2022-02-03 17:48:15.392446+00	\N	60.7	83.2	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	e2426f52bdb09acacf3b5aa0a0340731	mobilenet_v1_0.5_224_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.5_224_Quant	the output label	classification	1.0
229	2022-02-03 17:48:15.396661+00	2022-02-03 17:48:15.396661+00	\N	62.1	83.9	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	dcd24ae3690aaf27f1acfbe6d10ec1a3	mobilenet_v1_0.75_128_frozen.pb			4			unrestricted	MobileNet_v1_0.75_128	the output label	classification	1.0
230	2022-02-03 17:48:15.401231+00	2022-02-03 17:48:15.401231+00	\N	55.8	78.8	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	1872803beb64c5813b458e45bce1d52f	mobilenet_v1_0.75_128_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.75_128_Quant	the output label	classification	1.0
231	2022-02-03 17:48:15.406067+00	2022-02-03 17:48:15.406067+00	\N	65.3	86.	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	80bb07b2e1fb30f58bd7e5fec802adae	mobilenet_v1_0.75_160_frozen.pb			4			unrestricted	MobileNet_v1_0.75_160	the output label	classification	1.0
232	2022-02-03 17:48:15.411141+00	2022-02-03 17:48:15.411141+00	\N			CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	f9b875858c908b2315f40f821645e67f	mobilenet_v1_0.75_160_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.75_160_Quant	the output label	classification	1.0
246	2022-02-03 17:48:15.47998+00	2022-02-03 17:48:15.47998+00	\N	76.8	93.2	CNN	Cheng Li	ImageNet	An image-classification network built of layers that learn residual functions w.r.t layer inputs. This model is from TensorFlow Models Slim (resnet_v1_152_2016_08_28.tar.gz)\n	cf460292f3c82b73e35a0fc9ebaa69c4	resnet_v1_152_frozen.pb			4			unrestricted	ResNet_v1_152	the output label	classification	1.0
233	2022-02-03 17:48:15.415633+00	2022-02-03 17:48:15.415633+00	\N	67.2	87.3	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	5dd55f5254cb77f4e42835a591de7d8c	mobilenet_v1_0.75_192_frozen.pb			4			unrestricted	MobileNet_v1_0.75_192	the output label	classification	1.0
234	2022-02-03 17:48:15.420447+00	2022-02-03 17:48:15.420447+00	\N	66.1	86.4	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	3d63ab2bf42dbf5fdf9624733c2ca3c8	mobilenet_v1_0.75_192_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.75_192_Quant	the output label	classification	1.0
235	2022-02-03 17:48:15.425168+00	2022-02-03 17:48:15.425168+00	\N	68.4	88.2	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	d8535f9da0fd671d1cd1b86888ce6d11	mobilenet_v1_0.75_224_frozen.pb			4			unrestricted	MobileNet_v1_0.75_224	the output label	classification	1.0
236	2022-02-03 17:48:15.42966+00	2022-02-03 17:48:15.42966+00	\N	66.8	87.	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	bf0d7b02c9f2c70620065b814a76442f	mobilenet_v1_0.75_224_quant_frozen.pb			4			unrestricted	MobileNet_v1_0.75_224_Quant	the output label	classification	1.0
237	2022-02-03 17:48:15.434387+00	2022-02-03 17:48:15.434387+00	\N	65.2	85.8	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	e0e2d7f23f2bc75f93d10a049c7a86c4	mobilenet_v1_1.0_128_frozen.pb			4			unrestricted	MobileNet_v1_1.0_128	the output label	classification	1.0
238	2022-02-03 17:48:15.439895+00	2022-02-03 17:48:15.439895+00	\N	63.4	84.2	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	81ae6bd74c74cf7096f7c9adf833d986	mobilenet_v1_1.0_128_quant_frozen.pb			4			unrestricted	MobileNet_v1_1.0_128_Quant	the output label	classification	1.0
239	2022-02-03 17:48:15.445188+00	2022-02-03 17:48:15.445188+00	\N	68.	87.7	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	0733327af76a83409c974979873bc9c7	mobilenet_v1_1.0_160_frozen.pb			4			unrestricted	MobileNet_v1_1.0_160	the output label	classification	1.0
240	2022-02-03 17:48:15.450316+00	2022-02-03 17:48:15.450316+00	\N			CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	fcf4cb5916bc2d5f7849bc44206ce69d	mobilenet_v1_1.0_160_quant_frozen.pb			4			unrestricted	MobileNet_v1_1.0_160_Quant	the output label	classification	1.0
241	2022-02-03 17:48:15.455729+00	2022-02-03 17:48:15.455729+00	\N	70.	89.2	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	1054749ae43d8abeaf2091dddfee7b04	mobilenet_v1_1.0_192_frozen.pb			4			unrestricted	MobileNet_v1_1.0_192	the output label	classification	1.0
242	2022-02-03 17:48:15.460697+00	2022-02-03 17:48:15.460697+00	\N	69.2	88.3	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	85b291b2662a1fb049b41478f46914a4	mobilenet_v1_1.0_192_quant_frozen.pb			4			unrestricted	MobileNet_v1_1.0_192_Quant	the output label	classification	1.0
243	2022-02-03 17:48:15.465294+00	2022-02-03 17:48:15.465294+00	\N	70.9	89.9	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	7f564c782f0141e4e7bdc5161a6cc2f4	mobilenet_v1_1.0_224_frozen.pb			4			unrestricted	MobileNet_v1_1.0_224	the output label	classification	1.0
244	2022-02-03 17:48:15.470613+00	2022-02-03 17:48:15.470613+00	\N	70.1	88.9	CNN	Jingning Tang	ImageNet	MobileNet is a general architecture and can be used for multiple use cases. Depending on the use case, it can use different input layer size and different width factors. This allows different width models to reduce the number of multiply-adds and thereby reduce inference cost on mobile devices. This network consists of 224 layers and achieves 70.9 top-1 and 89.9 top-5 accuracy.\n	fb464017c6275ee283dc718fe7b83e17	mobilenet_v1_1.0_224_quant_frozen.pb			4			unrestricted	MobileNet_v1_1.0_224_Quant	the output label	classification	1.0
245	2022-02-03 17:48:15.475287+00	2022-02-03 17:48:15.475287+00	\N	76.4	92.9	CNN	Cheng Li	ImageNet	An image-classification network built of layers that learn residual functions w.r.t layer inputs. This model is from TensorFlow Models Slim (resnet_v1_101_2016_08_28.tar.gz)\n	939ed8e447ef607fea631c568fd1dd05	resnet_v1_101_frozen.pb			4			unrestricted	ResNet_v1_101	the output label	classification	1.0
247	2022-02-03 17:48:15.485092+00	2022-02-03 17:48:15.485092+00	\N	75.2	92.2	CNN	Cheng Li	ImageNet	An image-classification network built of layers that learn residual functions w.r.t layer inputs. This network consists of 50 layers and achieves 75.2 top-1 and 92.2 top-5 accuracy on ILSVRC-2015. This model is from TensorFlow Models Slim (resnet_v1_50_2016_08_28.tar.gz).\n	b153619627b5811a3b96c255126dd507	resnet_v1_50_frozen.pb			4			unrestricted	ResNet_v1_50	the output label	classification	1.0
248	2022-02-03 17:48:15.49093+00	2022-02-03 17:48:15.49093+00	\N	77.0	93.7	CNN	Cheng Li	ImageNet	An image-classification network built of layers that learn residual functions w.r.t layer inputs. This model is from TensorFlow Models Slim (resnet_v2_101_2017_04_14.tar.gz).\n	5c3490640ea43a1cf93fe908b7e32947	resnet_v2_101_frozen.pb			4			unrestricted	ResNet_v2_101	the output label	classification	1.0
249	2022-02-03 17:48:15.495774+00	2022-02-03 17:48:15.495774+00	\N	77.8	94.1	CNN	Cheng Li	ImageNet	An image-classification network built of layers that learn residual functions w.r.t layer inputs. This model is from TensorFlow Models Slim (resnet_v2_152_2017_04_14.tar.gz).\n	bb160c9e548566ebb1225396893963be	resnet_v2_152_frozen.pb			4			unrestricted	ResNet_v2_152	the output label	classification	1.0
250	2022-02-03 17:48:15.500575+00	2022-02-03 17:48:15.500575+00	\N	75.6	92.8	CNN	Cheng Li	ImageNet	An image-classification network built of layers that learn residual functions w.r.t layer inputs. This model is from TensorFlow Models Slim (resnet_v2_50_2017_04_14.tar.gz).\n	b7222f53a052c9a51aa6c6b96249d171	resnet_v2_50_frozen.pb			4			unrestricted	ResNet_v2_50	the output label	classification	1.0
251	2022-02-03 17:48:15.50565+00	2022-02-03 17:48:15.50565+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use rfcn_resnet101_coco_2018_01_28 from TensorFlow detection model zoo.\n	5538b70ce09cedf3c656157e4a3b06f1	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/rfcn_resnet101_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	RFCN_ResNet101_COCO	the output bounding box	boundingbox	1.0
252	2022-02-03 17:48:15.51043+00	2022-02-03 17:48:15.51043+00	\N			CNN	Cheng Li	DIV2K - bicubic downscaling x4 competition	TensorFlow Image Enhancement model, which is trained on DIV2K - bicubic downscaling x4 competition. Use SRGAN release 1.2.0 from TensorLayer SRGAN repo.\n	4af37a6975db591bfd1c780eb8019f97	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/srgan_1.2/frozen_model.pb			4			Apache License, Version 2.0	SRGAN	the output image	image	1.0
253	2022-02-03 17:48:15.515241+00	2022-02-03 17:48:15.515241+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssd_inception_v2_coco_2018_01_28 from TensorFlow detection model zoo.\n	22632401e2114b3a0fc79db7b02bbc7c	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_inception_v2_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSD_Inception_v2_COCO	the output bounding box	boundingbox	1.0
254	2022-02-03 17:48:15.519925+00	2022-02-03 17:48:15.519925+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssd_mobilenet_v1_0.75_depth_300x300_coco14_sync_2018_07_03 from TensorFlow detection model zoo.\n	182839f117af757c4208f28ad25e3749	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_mobilenet_v1_0.75_depth_300x300_coco14_sync_2018_07_03/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSD_MobileNet_v1_0.75_Depth_300x300_COCO14_Sync	the output bounding box	boundingbox	1.0
255	2022-02-03 17:48:15.524652+00	2022-02-03 17:48:15.524652+00	\N			CNN	Cheng Li	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssd_mobilenet_v1_coco_2018_01_28 from TensorFlow detection model zoo.\n	c9df908a779062ce00abe8f98e4a3eb1	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_mobilenet_v1_coco_2018_01_28/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSD_MobileNet_v1_COCO	the output bounding box	boundingbox	1.0
256	2022-02-03 17:48:15.529224+00	2022-02-03 17:48:15.529224+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssd_mobilenet_v1_fpn_shared_box_predictor_640x640_coco14_sync_2018_07_03 from TensorFlow detection model zoo.\n	bd60c1d92f4f7985fce54ecc77768ef1	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_mobilenet_v1_fpn_shared_box_predictor_640x640_coco14_sync_2018_07_03/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSD_MobileNet_v1_FPN_Shared_Box_Predictor_640x640_COCO14_Sync	the output bounding box	boundingbox	1.0
257	2022-02-03 17:48:15.533539+00	2022-02-03 17:48:15.533539+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssd_mobilenet_v1_ppn_shared_box_predictor_300x300_coco14_sync_2018_07_03 from TensorFlow detection model zoo.\n	157acb6f72f214655252d59d5040be54	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_mobilenet_v1_ppn_shared_box_predictor_300x300_coco14_sync_2018_07_03/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSD_MobileNet_v1_PPN_Shared_Box_Predictor_300x300_COCO14_Sync	the output bounding box	boundingbox	1.0
258	2022-02-03 17:48:15.537834+00	2022-02-03 17:48:15.537834+00	\N			CNN	Cheng Li	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssd_mobilenet_v2_coco_2018_03_29 from TensorFlow detection model zoo.\n	310fbd22691b984c709f2dbf6553f58e	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_mobilenet_v2_coco_2018_03_29/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSD_MobileNet_v2_COCO	the output bounding box	boundingbox	1.0
259	2022-02-03 17:48:15.542101+00	2022-02-03 17:48:15.542101+00	\N			CNN	Cheng Li	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssd_resnet50_v1_fpn_shared_box_predictor_640x640_coco14_sync_2018_07_03 from TensorFlow detection model zoo.\n	753c589fa596c855e42cf82eb463c637	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssd_resnet50_v1_fpn_shared_box_predictor_640x640_coco14_sync_2018_07_03/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSD_ResNet50_FPN_Shared_Box_Predictor_640x640_COCO14_Sync	the output bounding box	boundingbox	1.0
260	2022-02-03 17:48:15.546628+00	2022-02-03 17:48:15.546628+00	\N			CNN	Jingning Tang	COCO	TensorFlow Object Detection model, which is trained on the COCO (Common Objects in Context) dataset. Use ssdlite_mobilenet_v2_coco_2018_05_09 from TensorFlow detection model zoo.\n	87a63b4b0b7cb492bff0bead10af7fae	https://s3.amazonaws.com/store.carml.org/models/tensorflow/models/ssdlite_mobilenet_v2_coco_2018_05_09/frozen_inference_graph.pb			4			Apache License, Version 2.0	SSDLite_MobileNet_v2_COCO	the output bounding box	boundingbox	1.0
261	2022-02-03 17:48:15.552138+00	2022-02-03 17:48:15.552138+00	\N	71.5	89.8	CNN	Cheng Li	ImageNet	An image-classification convolutional network. VGG19 uses a network with 19 layers of 3x3 convolution filters. VGG19 achieves 71.1% top-1 and 89.8% top-5 accuracy on the ImageNet challenge dataset in 2015. This model is from TensorFlow Models Slim (vgg_16_2016_08_28.tar.gz).\n	b44e96ab732a819710c74ec2462659ac	vgg_16_frozen.pb			4			unrestricted	VGG16	the output label	classification	1.0
262	2022-02-03 17:48:15.557443+00	2022-02-03 17:48:15.557443+00	\N	71.1	89.8	CNN	Cheng Li	ImageNet	An image-classification convolutional network. VGG19 uses a network with 19 layers of 3x3 convolution filters. VGG19 achieves 71.1% top-1 and 89.8% top-5 accuracy on the ImageNet challenge dataset in 2015. This model is from TensorFlow Models Slim (vgg_16_2016_08_28.tar.gz).\n	9b09d4bdc8fcee61678ec44107d92190	vgg_19_frozen.pb			4			unrestricted	VGG19	the output label	classification	1.0
263	2022-02-03 17:48:15.557443+00	2022-02-03 17:48:15.557443+00	\N	71.1	89.8	CNN	C3SR	Mock	A model for testing against the Mock agent.	\N	\N	\N	\N	5	\N	\N	unrestricted	Mock	the output label	classification	1.0
\.


--
-- Data for Name: trial_inputs; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.trial_inputs (id, created_at, updated_at, deleted_at, trial_id, url, user_id) FROM stdin;
\.


--
-- Data for Name: trials; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.trials (id, created_at, updated_at, deleted_at, model_id, completed_at, result, experiment_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: c3sr
--

COPY public.users (id, created_at, updated_at, deleted_at) FROM stdin;
anonymous	2022-02-03 17:22:40.788808+00	2022-02-03 17:22:40.788808+00	\N
\.


--
-- Name: architectures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: c3sr
--

SELECT pg_catalog.setval('public.architectures_id_seq', 5, true);


--
-- Name: frameworks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: c3sr
--

SELECT pg_catalog.setval('public.frameworks_id_seq', 5, true);


--
-- Name: models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: c3sr
--

SELECT pg_catalog.setval('public.models_id_seq', 263, true);


--
-- Name: trial_inputs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: c3sr
--

SELECT pg_catalog.setval('public.trial_inputs_id_seq', 1, false);


--
-- Name: architectures architectures_pkey; Type: CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.architectures
    ADD CONSTRAINT architectures_pkey PRIMARY KEY (id);


--
-- Name: experiments experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_pkey PRIMARY KEY (id);


--
-- Name: frameworks frameworks_pkey; Type: CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.frameworks
    ADD CONSTRAINT frameworks_pkey PRIMARY KEY (id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: trial_inputs trial_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.trial_inputs
    ADD CONSTRAINT trial_inputs_pkey PRIMARY KEY (id);


--
-- Name: trials trials_pkey; Type: CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.trials
    ADD CONSTRAINT trials_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_architectures_deleted_at; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_architectures_deleted_at ON public.architectures USING btree (deleted_at);


--
-- Name: idx_experiments_deleted_at; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_experiments_deleted_at ON public.experiments USING btree (deleted_at);


--
-- Name: idx_frameworks_deleted_at; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_frameworks_deleted_at ON public.frameworks USING btree (deleted_at);


--
-- Name: idx_models_deleted_at; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_models_deleted_at ON public.models USING btree (deleted_at);


--
-- Name: idx_models_description; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_models_description ON public.models USING btree (lower(description));


--
-- Name: idx_models_name; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_models_name ON public.models USING btree (lower(name));


--
-- Name: idx_trial_inputs_deleted_at; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_trial_inputs_deleted_at ON public.trial_inputs USING btree (deleted_at);


--
-- Name: idx_trials_deleted_at; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_trials_deleted_at ON public.trials USING btree (deleted_at);


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: public; Owner: c3sr
--

CREATE INDEX idx_users_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: experiments fk_experiments_user; Type: FK CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT fk_experiments_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: architectures fk_frameworks_architectures; Type: FK CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.architectures
    ADD CONSTRAINT fk_frameworks_architectures FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: models fk_models_framework; Type: FK CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT fk_models_framework FOREIGN KEY (framework_id) REFERENCES public.frameworks(id);


--
-- Name: trial_inputs fk_trial_inputs_user; Type: FK CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.trial_inputs
    ADD CONSTRAINT fk_trial_inputs_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: trial_inputs fk_trials_inputs; Type: FK CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.trial_inputs
    ADD CONSTRAINT fk_trials_inputs FOREIGN KEY (trial_id) REFERENCES public.trials(id);


--
-- Name: trials fk_trials_model; Type: FK CONSTRAINT; Schema: public; Owner: c3sr
--

ALTER TABLE ONLY public.trials
    ADD CONSTRAINT fk_trials_model FOREIGN KEY (model_id) REFERENCES public.models(id);


--
-- PostgreSQL database dump complete
--

